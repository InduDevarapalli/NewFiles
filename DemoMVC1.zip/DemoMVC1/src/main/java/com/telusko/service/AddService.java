package com.telusko.service;

public class AddService {
 
	public int multiply(int i, int j)
	{
		return i*j;
	}
	
	
}
