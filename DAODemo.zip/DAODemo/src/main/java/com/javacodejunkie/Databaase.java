package com.javacodejunkie;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Databaase {
	
	private static String Url = "jdbc:mysql://localhost:3306/training";
	private static String user = "root";
	private static String password = "mysql123@";
	
	private Databaase() {
	
	}

		public static Connection getConnection() throws SQLException {
			Connection connection = null;
			connection = DriverManager.getConnection(Url, user, password);
		return connection;
		}
}

