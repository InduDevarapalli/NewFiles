package com.javacodejunkie;

public interface EmployeeDAO extends DAO<Employee> {

}
