package com.javacodejunkie;

import java.sql.SQLException;
import java.util.List;

public class EmployeeDAOImpl implements EmployeeDAO{ 


public Employee get(int id) throws SQLException {
	// TODO Auto-generated method stub
	return null;
}

public List<Employee> getAll() throws SQLException {
	// TODO Auto-generated method stub
	return null;
}

public int save(Employee employee) throws SQLException {
	// TODO Auto-generated method stub
	return 0;
}

public int insert(Employee employee) throws SQLException {
	// TODO Auto-generated method stub
	return 0;
}

public int update(Employee employee) throws SQLException {
	// TODO Auto-generated method stub
	return 0;
}

public int delete(Employee employee) {
	// TODO Auto-generated method stub
	return 0;
}
}

