package com.main;

import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.dao.EmployeeDAO;
import com.to.Employee;

public class Main {

	public static void main(String[] args){
		ApplicationContext ap = new ClassPathXmlApplicationContext("beans.xml");
	    EmployeeDAO dao=(EmployeeDAO)ap.getBean("edao");
	    
	    Employee e1 = new Employee();  //Adding employee details to the database
	    e1.setEid(103);
	    e1.setEname("indu");
	    e1.setAge(40);
	    e1.setPassword("yy");
	    int count = dao.addEmployee(e1);
	    System.out.println(count + "records added");
	    
	List<Employee> list = dao.getAllEmployees(); //printing all employee details
	for(Employee employee : list){
		System.out.println(employee);
		}
	}
}
	
	
	

